#include <stdio.h>
#include <math.h>

int LENGTH= 6.0;
int HEIGHT= 4.0;
#define N 6 // Number of points along X-axis
#define M 4 // Number of points along Y-axis
#define MAX_ITER 10000
#define error 1e-6

// Initialize the temperature array and apply boundary conditions
void initialize(double temperature[N][M]) {

for (int i = 0; i < N-1; i++) {
       for (int j = 0; j < M; j++) {
     if (i == 0 || j == M-1 ) {
      temperature[i][j] = 0.0;
            }
    else if(j==0){
        for(i=0;i<N/6;i++){
         temperature[i][j]=0;
        for(i=N/6;i<N;i++){
        temperature[i][j]=100;
            }}}
         else {
        temperature[i][j] = 0.0;
            }}}}

// Gauss-Jacobi iteration
void gaussJacobi(double temperature[N][M]) {
    double temp[N][M];

    for (int k = 0; k < MAX_ITER; k++) {
        for (int i = 1; i < N - 1; i++) {
         for (int j = 1; j < M - 1; j++) {
            temp[i][j] = 0.25 * (temperature[i-1][j] + temperature[i+1][j] + temperature[i][j-1] + temperature[i][j+1]);
            }
        }

        double maxDiff = 0.0;

    for (int i = 1; i < N - 1; i++) {
        for (int j = 1; j < M - 1; j++) {
        double diff;
        diff = (temp[i][j] - temperature[i][j]);
        if (diff > maxDiff) {
            maxDiff = diff;
                }
            temperature[i][j] = temp[i][j];
            }}

        if (maxDiff < error) {
            printf("Converged after %d iterations.\n", k + 1);
            break;
        }
    }
    for(int j=0;j<M-1;j++){
        temperature[N-1][j]=temperature[N-2][j];
    }
    }

void printTemperature(double temperature[N][M]) {

    for (int j = M - 1; j >= 0; j--) {
        for (int i = 0; i < N; i++) {
            printf("%.3f ", temperature[i][j]);

        }
        printf("\n");}
}

void main() {
    double temperature[N][M];

    initialize(temperature);
    gaussJacobi(temperature);
    printTemperature(temperature);
}
