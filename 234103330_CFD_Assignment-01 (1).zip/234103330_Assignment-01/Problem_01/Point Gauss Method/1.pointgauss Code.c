#include <stdio.h>
#include <math.h>

int LENGTH= 6.0;
int HEIGHT= 4.0;
int N= 12; // Number of points along X-axis
int M= 4; // Number of points along Y-axis
int MAX_ITER= 10000;
int error= 1e-6;

// Initialize the temperature array and apply boundary conditions
void initialize(double temperature[N][M]) {
    for (int i = 0; i < N; i++) {
    for (int j = 0; j < M; j++) {
     if (i == 0 || j == M-1) {
     temperature[i][j] = 0.0;
            }
     else if (j == 0) {
        for (int k = 0; k < N / 6; k++) {
         temperature[k][j] = 0;
                }
        for (int k = N / 6; k < N; k++) {
        temperature[k][j] = 100;
                }
            }
     else {
             temperature[i][j] = 0.0;
            }}}}

// Point Gauss-Seidel iteration
void gaussSeidel(double temperature[N][M]) {
    for (int k = 0; k < MAX_ITER; k++) {
        for (int i = 1; i < N - 1; i++) {
        for (int j = 1; j < M - 1; j++) {
         double temp = 0.25 * (temperature[i - 1][j] + temperature[i + 1][j] + temperature[i][j - 1] + temperature[i][j + 1]);
        temperature[i][j] = temp;
            }
        }

        double maxDiff = 0.0;
        double temp;

        for (int i = 1; i < N - 1; i++) {
         for (int j = 1; j < M - 1; j++) {
        double diff = fabs(temperature[i][j] - temp);
            if (diff > maxDiff) {
            maxDiff = diff;
                }}}

        if (maxDiff < error) {
            printf("Converged after %d iterations.\n", k + 1);
            break;
        }}
    for (int j = 0; j < M - 1; j++) {
        temperature[N - 1][j] = temperature[N - 2][j];
    }}

void printTemperature(double temperature[N][M]) {
    for (int j = M - 1; j >= 0; j--) {
        for (int i = 0; i < N; i++) {
        printf("%.3f ", temperature[i][j]);
        }
        printf("\n");
    }}

void main() {
    double temperature[N][M];

    initialize(temperature);
    gaussSeidel(temperature);
    printTemperature(temperature);
}
