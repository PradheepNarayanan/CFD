#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
    int i, j, m, n, iteration=0;
    double dx, dy,b, error=1.0;
     printf("enter the value of M in MxN grid: ");
    scanf("%d",&m);
    printf("\nenter the value of N in MxN grid: ");
    scanf("%d\n",&n);

    dx = 6.0/(m-1);
    dy = 4.0/ (n-1);
    b = dx/dy;

    FILE *f1;
    f1 = fopen("HEAT_TDMA.txt","w");
    if(f1== NULL){
            printf("\n cannot open file\n");
            exit(1);
    }

    double ai, bi, ci, di[n-2], pi[m-2], qi[m-2];
    double T_old[m+2][n+2], T_new[m+2][n+2];
    ai=-2.0*(1+b*b);
    bi=1.0;
    ci=1.0;

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            T_new[i][j] = 0.0;
        }
    }

    for (int i = 0; i < m; i++)
    {
        T_new[i][0] = 1.0;  
    }

    for (int j = 0; j < n; j++)
    {
        T_new[0][j] = 1.0;  
    }

    for (int j = 0; j < n; j++)
    {
        T_new[n-1][j] = 1.0; 

    }

    for (int i = 0; i < m; i++)
    {
        T_new[i][m-1] = 0.0; 
    }

    do
    {
    error = 0.0;
        for(int j = 1; j < n-1; j ++){
        di[0] = -(b*b)*(T_new[0][j+1] + T_new[0][j-1]);
        pi[0] = -bi/ai;
        qi[0] = di[0]/ai;

        for(int i=1; i < m-1; i++){
            di[i] = -(b*b)*(T_new[i][j+1] + T_new[i][j-1]);;
            pi[i] = -(bi/(ai + ci*pi[i-1]));
            qi[i] = (di[i] - ci*qi[i-1])/(ai + ci*pi[i-1]);
        }

        for(int i=m-2; i>0; i--){
            T_old[i][j] = T_new[i][j];
                T_new[i][j] = pi[i]*T_new[i+1][j]+qi[i];
              error+=pow( (T_new[i][j] - T_old[i][j]),2.0 );
        }

    }

    
    error = sqrt( error/((m-2)*(n-2)) );
    printf( "\niteration = %d \t" "Error =  %.10lf", iteration, error);
    fprintf(f1, "%d \t %.10lf\n", iteration, error);

    iteration++;
    } while (error > 1e-6);

    FILE *f2;
    f2=fopen("heat_TDMA.plt","w");
    if(f2==NULL){
        printf("\n cannot open file. \n");
        exit(1);
    }

    fprintf(f2, "variables = \"x\", \"y\", \"T\" \n\n");
    fprintf(f2, "zone t = \"block1\", i=31,  j=31,  f=point\n\n");

    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            fprintf(f2, "%lf \t %lf \t %lf \t", i*dx, j*dy, T_new[i][j]);
        }
    }

    fclose(f1);
    fclose(f2);
    return 0;

}