#include <stdio.h>
#include <math.h>

int LENGTH=1.0;
int HEIGHT=1.0;
int NX=11; // Number of points along X-axis (including boundaries)
int NY=11; // Number of points along Y-axis (including boundaries)
int ITER=10000;
int treshold=1e-6;
int w=1.5; // Relaxation factor

// Initialize the temperature array and apply boundary conditions
void initialize(double temperature[NX][NY]) {
    for (int i = 0; i < NX; i++) {
     for (int j = 0; j < NY; j++) {
      if (i == 0 || i == NX - 1 || j == 0) {
        temperature[i][j] = 1.0;
        } else {
         temperature[i][j] = 0.0;
            }}}}

// Point PSOR iteration
void psor(double temperature[NX][NY]) {
    for (int iter = 0; iter < ITER; iter++) {
        double Diff = 0.0;
        
     for (int i = 1; i < NX - 1; i++) {
     for (int j = 1; j < NY - 1; j++) {
       double oldValue = temperature[i][j];
      temperature[i][j] = (1 - w) * oldValue + w * 0.25 * (temperature[i-1][j] + temperature[i+1][j] + temperature[i][j-1] + temperature[i][j+1]);
     double diff = fabs(temperature[i][j] - oldValue);
                
         if (diff > Diff) {
            Diff = diff;
         }
            }}
        
        
     if (Diff < treshold) {
          printf("Converged after %d iterations.\n", iter + 1);
            break;
        }}}

// Print the temperature array
void printTemperature(double temperature[NX][NY]) {
    for (int j = NY - 1; j >= 0; j--) {
    for (int i = 0; i < NX; i++) {
          printf("%.3f ", temperature[i][j]);
        }
     printf("\n");
    }
}

int main() {
    double temperature[NX][NY];
    
    initialize(temperature);
    psor(temperature);
    printTemperature(temperature);
    
    return 0;
}
