#include <stdio.h>
#include <math.h>

#define NX 11 // Number of divisions along X-axis (including boundaries)
#define NY 11 // Number of divisions along Y-axis (including boundaries)
#define L 1.0 // Length of the domain in meters
#define H 1.0 // Height of the domain in meters
#define DELTA_X (L / (NX - 1))
#define DELTA_Y (H / (NY - 1))
#define ALPHA 0.1 // Thermal diffusivity

// Function to initialize the temperature at boundaries and interior nodes
void initializeTemperature(double temp[][NY]) {
    for (int i = 0; i < NX; i++) {
        temp[i][0] = 1.0; // Bottom boundary
        temp[i][NY - 1] = 0.0; // Top boundary
    }

    for (int j = 1; j < NY - 1; j++) {
        temp[0][j] = 1.0; // Left boundary
        temp[NX - 1][j] = 1.0; // Right boundary
    }
}

int main() {
    double temp[NX][NY]; // Temperature matrix
    double temp_new[NX][NY]; // New temperature matrix

    initializeTemperature(temp);

    double delT = 0.001; // Time step
    int numSteps = 1000; // Number of time steps

    // ADI iterations
    for (int step = 0; step < numSteps; step++) {
        // Implicit scheme along X-axis
        for (int j = 1; j < NY - 1; j++) {
            for (int i = 1; i < NX - 1; i++) {
                temp_new[i][j] = temp[i][j] + ALPHA * delT / (DELTA_X * DELTA_X) *
                                (temp[i + 1][j] - 2 * temp[i][j] + temp[i - 1][j]);
            }
        }

        // Implicit scheme along Y-axis
        for (int i = 1; i < NX - 1; i++) {
            for (int j = 1; j < NY - 1; j++) {
                temp[i][j] = temp_new[i][j] + ALPHA * delT / (DELTA_Y * DELTA_Y) *
                            (temp_new[i][j + 1] - 2 * temp_new[i][j] + temp_new[i][j - 1]);
            }
        }
    }

    // Printing the temperature distribution
    printf("Temperature Distribution:\n");
    for (int j = NY - 1; j >= 0; j--) {
        for (int i = 0; i < NX; i++) {
            printf("%.2f\t", temp[i][j]);
        }
        printf("\n");
    }

    return 0;
}
