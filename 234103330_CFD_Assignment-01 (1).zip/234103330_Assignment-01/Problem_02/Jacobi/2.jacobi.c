#include <stdio.h>
#include <math.h>
int length=1.0;
int height=1.0;
int NX=10; 
int NY=10; 
int MAX_ITER=10000;
int treshold=1e-6;

//Initializing boundary conditions
void assign(double temperature[NX][NY]) {
    for (int i = 0; i < NX; i++) {
        for (int j = 0; j < NY; j++) {
            if (i == 0 || i == NX - 1 || j == 0 ) {
                temperature[i][j] = 1.0;
            } else {
                temperature[i][j] = 0.0;
        }
        }
        }
}

void gaussJacobi(double temperature[NX][NY]) {
    double temp[NX][NY];
    
    for (int iteration = 0; iteration < MAX_ITER; iteration++) {
     for (int i = 1; i < NX - 1; i++) {
        for (int j = 1; j < NY - 1; j++) {
         temp[i][j] = 0.25 * (temperature[i-1][j] + temperature[i+1][j] + temperature[i][j-1] + temperature[i][j+1]);
        }
        }
        
        double Diff = 0.0;
        
        for (int i = 1; i < NX - 1; i++) {
         for (int j = 1; j < NY - 1; j++) {
            double diff = fabs(temperature[i][j] - temp[i][j]);
            if (diff > Diff) {
                    Diff = diff;
            }
                temperature[i][j] = temp[i][j];
        }
        }
        
        if (Diff < treshold) {
            printf("Converges after %d iterations.\n", iteration + 1);
            break;
    }
    }
  }

// Printing the temperature array
void print(double temperature[NX][NY]) {
    for (int j = NY - 1; j >= 0; j--) {
        for (int i = 0; i < NX; i++) {
            printf("%.3f ", temperature[i][j]);
        }
        printf("\n");
    }
}

int main() {
    double temperature[NX][NY];
    
    assign(temperature);
    gaussJacobi(temperature);
    print(temperature);
    
    return 0;
}

