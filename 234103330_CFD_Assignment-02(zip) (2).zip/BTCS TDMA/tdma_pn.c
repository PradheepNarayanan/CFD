#include <stdio.h>
#include <math.h>

int main()
{
    int num_points = 101, iteration = 0;
    double temperature[101] = {0}, temp[101] = {0}, dx = 1.0 / (num_points - 1), dt = 1.0 * pow(10, -2), time = 0, error = 0, error_history[10000] = {0}, time_history[10000] = {0};
    double gamma = dt / (100 * pow(dx, 2));
    double epsilon = 1.0e-6; // Declare and initialize epsilon

    temperature[0] = 0;
    temperature[num_points - 1] = 1;
    temp[num_points - 1] = 1;

    do
    {
        error = 0;

        for (int i = 1; i < num_points - 1; i++)
            temp[i] = temperature[i];

        double p[101] = {0}, q[101] = {0};
        p[0] = 0;
        q[0] = 0;

        for (int i = 1; i < num_points; i++)
        {
            p[i] = -gamma / (-(1 + 2 * gamma) + (gamma * p[i - 1]));
            q[i] = (temperature[i] + (gamma * q[i - 1])) / ((1 + 2 * gamma) - gamma * p[i - 1]);
        }

        q[num_points - 1] = temperature[num_points - 1];

        for (int i = num_points - 2; i > 0; i--)
        {
            temperature[i] = (p[i] * temperature[i + 1]) + q[i];
            error = error + pow(temperature[i] - temp[i], 2);
        }

        double norm = error / (num_points - 2);
        error = sqrt(norm);
        error_history[iteration] = error;
        time_history[iteration] = time;

        if (iteration == 100)
        {
            printf("t=1s\n");
            FILE *wr = fopen("BTCS_TDMA_t1.dat", "w");
            fprintf(wr, "velocity\ty\ttime\n");

            for (int i = 0; i < num_points; i++)
            {
                printf("%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
                fprintf(wr, "%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
            }

            fclose(wr);
        }

        if (iteration == 500)
        {
            printf("t=5s\n");
            FILE *wr = fopen("BTCS_TDMA_t5.dat", "w");
            fprintf(wr, "velocity\ty\ttime\n");

            for (int i = 0; i < num_points; i++)
            {
                printf("%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
                fprintf(wr, "%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
            }

            fclose(wr);
        }

        if (iteration == 1000)
        {
            printf("t=10s\n");
            FILE *wr = fopen("BTCS_TDMA_t10.dat", "w");
            fprintf(wr, "velocity\ty\ttime\n");

            for (int i = 0; i < num_points; i++)
            {
                printf("%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
                fprintf(wr, "%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
            }

            fclose(wr);
        }

        if (iteration == 2500)
        {
            printf("t=25s\n");
            FILE *wr = fopen("BTCS_TDMA_t25.dat", "w");
            fprintf(wr, "velocity\ty\ttime\n");

            for (int i = 0; i < num_points; i++)
            {
                printf("%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
                fprintf(wr, "%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
            }

            fclose(wr);
        }

        if (iteration == 5000)
        {
            printf("t=50s\n");
            FILE *wr = fopen("BTCS_TDMA_t50.dat", "w");
            fprintf(wr, "velocity\ty\ttime\n");

            for (int i = 0; i < num_points; i++)
            {
                printf("%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
                fprintf(wr, "%lf\t%lf\t%lf\n", temperature[i], (dx * i), time);
            }

            fclose(wr);
        }

        iteration++;
        time = time + dt;

    } while (error > epsilon); // Use epsilon as the convergence criterion
    time = 0;

    FILE *error_file = fopen("BTCS_error.dat", "w");
    fprintf(error_file, "error\ttime\n");

    for (int i = 0; i < iteration; i++)
    {
        printf("%lf\t%lf\n", error_history[i], time_history[i]);
        fprintf(error_file, "%lf\t%lf\n", error_history[i], time_history[i]);

time = time + dt;
    }

    fclose(error_file);

    FILE *iteration_file = fopen("BTCS_itr.dat", "w");
    fprintf(iteration_file, "error\titeration\n");

    for (int i = 0; i < iteration; i++)
    {
        printf("%lf\t%d\n", error_history[i], i);
        fprintf(iteration_file, "%lf\t%d\n", error_history[i], i);
    }

    fclose(iteration_file);

    return 0;
}
