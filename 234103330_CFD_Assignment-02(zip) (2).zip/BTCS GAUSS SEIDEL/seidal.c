#include <stdio.h>
#include <math.h>

int main() {
    int num_points = 101, iteration = 0;
    double temperature[101] = {0}, previous_temp[101] = {0}, delta_x = 1.0 / (double)(num_points - 1), delta_t = 1.0e-2, time = 0, variation = 0, norm, error, error_values[10000] = {0}, time_values[10000] = {0};

    temperature[0] = 0;
    temperature[num_points - 1] = 1;

    do {
        variation = 0;

        // Copy current values of 'temperature' to 'previous_temp'
        for (int i = 0; i < num_points; i++)
            previous_temp[i] = temperature[i];

        // Perform Gauss-Seidel iteration
        for (int i = 1; i < num_points - 1; i++) {
            temperature[i] = 0.5 * (previous_temp[i - 1] + previous_temp[i + 1] + delta_x * delta_x);
            variation += pow(temperature[i] - previous_temp[i], 2);
        }

        // Calculate the norm and error
        norm = variation / (num_points - 2);
        error = sqrt(norm);
        error_values[iteration] = error;
        time_values[iteration] = time;

        // Output results at specific iterations
        if (iteration == 100) {
            printf("t=1s\n");
            printf("temperature\ty\n");
            FILE *output_file = fopen("GaussSeidel_t1.dat", "w");
            for (int i = 0; i < num_points; i++) {
                printf("%lf\t%lf\n", temperature[i], delta_x * i);
                fprintf(output_file, "%lf\t%lf\n", temperature[i], delta_x * i);
            }
            fclose(output_file);
        }

        if (iteration == 500) {
            printf("t=5s\n");
            printf("temperature\ty\n");
            FILE *output_file = fopen("GaussSeidel_t5.dat", "w");
            for (int i = 0; i < num_points; i++) {
                printf("%lf\t%lf\n", temperature[i], delta_x * i);
                fprintf(output_file, "%lf\t%lf\n", temperature[i], delta_x * i);
            }
            fclose(output_file);
        }

        if (iteration == 1000) {
            printf("t=10s\n");
            printf("temperature\ty\n");
            FILE *output_file = fopen("GaussSeidel_t10.dat", "w");
            for (int i = 0; i < num_points; i++) {
                printf("%lf\t%lf\n", temperature[i], delta_x * i);
                fprintf(output_file, "%lf\t%lf\n", temperature[i], delta_x * i);
            }
            fclose(output_file);
        }

        iteration++;
        time += delta_t;
    } while (error > 1.0e-6);

    time = 0;
    printf("Total Number of Iterations: %d\n", iteration);
    printf("Error\tTime\t%lf\n", time);
    FILE *error_file = fopen("GaussSeidel_error.dat", "w");
    for (int i = 0; i < iteration; i++) {
        printf("%lf\t%lf\n", error_values[i], time_values[i]);
        fprintf(error_file, "%lf\t%lf\n", error_values[i], time_values[i]);
        time += delta_t;
    }
    fclose(error_file);

    FILE *iteration_file = fopen("GaussSeidel_itr.dat", "w");
    for (int i = 0; i < iteration; i++) {
        fprintf(iteration_file, "%lf\t%d\n", error_values[i], i);
    }
    fclose(iteration_file);

    return 0;
}
