#include <stdio.h>
#include <math.h>

int main() {
    int n = 101;  // Number of grid points
    int k = 0;    // Iteration count
    double u[101] = {0};   // Array for velocity
    double temp[101] = {0};   // Temporary array
    double dx = 1.0 / (double)(n - 1);  // Grid spacing
    double dt = 1e-2;  // Time step
    double t = 0;   // Current time
    double var = 0; // Variance
    double norm, error; // Error and normalization
    double error_history[10000] = {0}; // Array to store error history
    double time_history[10000] = {0}; // Array to store time history
    double p[101] = {0}; // Coefficient p
    double q[101] = {0}; // Coefficient q
    double g = dt / (100 * pow(dx, 2)); // g parameter
    FILE *velocity_file, *error_file, *iteration_file;

    u[0] = 0;
    u[n - 1] = 1;
    temp[n - 1] = 1;

    do {
        var = 0;

        // Store the previous time step values
        for (int i = 1; i < n - 1; i++)
            temp[i] = u[i];

        p[0] = 0;
        q[0] = 0;

        // Calculate p values
        for (int i = 1; i < n - 1; i++) {
            p[i] = g / (2 * ((1 + g) - (g * 0.5 * p[i - 1])));
        }

        // Calculate q values
        for (int i = 1; i < n - 1; i++) {
            q[i] = ((g * 0.5 * (u[i + 1] + u[i - 1])) - (u[i] * (g - 1)) + (g * 0.5 * q[i - 1])) / (1 + g - (0.5 * g * p[i - 1]));
        }

        p[n - 1] = 0;
        q[n - 1] = u[n - 1];

        // Update u values
        for (int i = n - 2; i > 0; i--) {
            u[i] = (p[i] * u[i + 1]) + q[i];
            var = var + pow(u[i] - temp[i], 2);
        }

        // Calculate error and store it in history
        norm = var / (n - 2);
        error = sqrt(norm);
        error_history[k] = error;
        time_history[k] = t;

        // Write velocity data to files at specific iterations
        if (k == 100) {
            printf("t=1s\n");
            printf("velocity\ty\n");
            velocity_file = fopen("CN_t1.dat", "w");
            for (int i = 0; i < n; i++) {
                printf("%f\t%f\n", u[i], (dx * i));
                fprintf(velocity_file, "%f\t%f\n", u[i], (dx * i));
            }
            fclose(velocity_file);
        }

        if (k == 500) {
            printf("t=5s\n");
            velocity_file = fopen("CN_t5.dat", "w");
            printf("velocity\ty\n");
            for (int i = 0; i < n; i++) {
                printf("%f\t%f\n", u[i], (dx * i));
                fprintf(velocity_file, "%f\t%f\n", u[i], (dx * i));
            }
            fclose(velocity_file);
        }

        if (k == 1000) {
            printf("t=10s\n");
            velocity_file = fopen("CN_t10.dat", "w");
            printf("velocity\ty\n");
            for (int i = 0; i < n; i++) {
                printf("%f\t%f\n", u[i], (dx * i));
                fprintf(velocity_file, "%f\t%f\n", u[i], (dx * i));
            }
            fclose(velocity_file);
        }

        k++;
        t = t + dt;

    } while (error > 1.0e-6);

    t = 0;
    printf("Total Number of iterations: %d\n", k);
    printf("error\ttime\t%f\n", t);

    // Write error and iteration data to files
    error_file = fopen("CN_error.dat", "w");
    for (int i = 0; i < k; i++) {
        printf("%f\t%f\n", error_history[i], time_history[i]);
        fprintf(error_file, "%f\t%f\n", error_history[i], time_history[i]);
        t = t + dt;
    }
    fclose(error_file);

    iteration_file = fopen("CN_itr.dat", "w");
    for (int i = 0; i < k; i++) {
        fprintf(iteration_file, "%f\t%d\n", error_history[i], i);
    }
    fclose(iteration_file);

    return 0;
}
