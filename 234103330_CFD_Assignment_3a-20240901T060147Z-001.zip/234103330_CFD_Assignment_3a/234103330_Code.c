#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
    int nx, ny, i, j;
    printf("\nEnter the number of nodes in x direction\n");
    scanf("%d", &nx);
    printf("\nEnter the number of nodes in y direction\n");
    scanf("%d", &ny);

    float length = 1.0, height = 1.0;
    float si_old[nx][ny], si[nx + 1][ny + 1], Re, w[nx][ny], w_old[nx + 1][ny + 1], u[nx][ny], v[nx][ny];

    printf("\nEnter the value of Reynolds Number\n");
    scanf("%f", &Re);

    float dx, dy;
    dx = length / (nx - 1);
    dy = height / (ny - 1);

    float b = dx / dy;
    float dx_sq, dy_sq, k;
    dx_sq = pow(dx, 2);
    dy_sq = pow(dy, 2);
    k = 2 * ((1 / dx_sq) + (1 / dy_sq));
    printf("%f\n", k);

    for (i = 1; i <= nx; i++) {
        for (j = 1; j <= ny; j++) {
            if (j == ny)
                u[i][ny] = 1.0;
            else
                u[i][j] = 0.0;
        }
    }

    for (i = 1; i <= nx; i++) {
        for (j = 1; j <= ny; j++) {
            v[i][j] = 0.0;
            si[i][j] = 0.0;

            if (j == 1) {
                w[i][j] = 0;
            } else if (j == ny) {
                w[i][ny] = (-2 * u[i][ny]) / dy;
            } else if (i == 1) {
                w[i][j] = 0;
            } else if (i == nx) {
                w[i][j] = 0;
            } else {
                w[i][j] = 0.0;
            }
        }
    }

    for (i = 1; i <= nx; i++)
        printf("%lf \t", w[i][ny]);

    int iter = 0;
    float s_err, v_err;
    FILE *file1 = fopen("Si_Error.dat", "w");

    for (iter = 1; iter <= 6000; iter++) {
        for (i = 1; i <= nx; i++) {
            for (j = 1; j <= ny; j++) {
                si_old[i][j] = si[i][j];
                w_old[i][j] = w[i][j];
            }
        }
        s_err = 0;

        for (j = 2; j < ny; j++) {
            for (i = 2; i < nx; i++) {
                si[i][j] = (((si[i + 1][j] + si[i - 1][j]) / dx_sq) + ((si[i][j + 1] + si[i][j - 1]) / dy_sq) + w[i][j]) / k;
                s_err = s_err + pow((si[i][j] - si_old[i][j]), 2);
            }
        }

        v_err = 0;
        for (j = 2; j < ny; j++) {
            for (i = 2; i < nx; i++) {
                u[i][j] = (si[i][j + 1] - si[i][j - 1]) / (2 * dy);
                v[i][j] = (si[i - 1][j] - si[i + 1][j]) / (2 * dx);

                w[i][j] = (Re / k) * (((w[i + 1][j] + w[i - 1][j]) / (dx_sq * Re)) +
                                      ((w[i][j + 1] + w[i][j - 1]) / (dy_sq * Re)) -
                                      ((u[i][j] * (w[i + 1][j] - w[i - 1][j]) / (2 * dx)) +
                                       (v[i][j] * (w[i][j + 1] - w[i][j - 1]) / (2 * dy))));
                v_err = v_err + pow((w[i][j] - w_old[i][j]), 2);
            }
        }

        v_err = sqrt(fabs(v_err)) / ((nx - 2) * (ny - 2));
        s_err = sqrt(fabs(s_err)) / ((nx - 2) * (ny - 2));

        printf("Iteration %d\t", iter);
        printf("SError %.10f\tVError %.10f\n", s_err, v_err);
        fprintf(file1, "%d\t%.10f\t%.10f\n", iter, s_err, v_err);

        for (j = 1; j <= ny; j++) {
            for (i = 1; i <= nx; i++) {
                if (j == ny) {
                    w[i][ny] = -2 * (si[i][ny - 1] - si[i][ny] + (u[i][j] * dy)) / dy_sq;
                } else if (i == nx) {
                    w[i][j] = -2 * (si[nx - 1][j] - si[nx][j]) / dx_sq;
                } else if (j == 1) {
                    w[i][j] = -2 * (si[i][2] - si[i][1]) / dy_sq;
                } else if (i == 1) {
                    w[i][j] = -2 * (si[2][j] - si[1][j]) / dx_sq;
                }
            }
        }

        if (s_err < pow(10, -6) && v_err < pow(10, -6))
            break;
    }
    fclose(file1);

    for (j = 2; j < ny; j++) {
        for (i = 2; i < nx; i++) {
            u[i][j] = (si[i][j + 1] - si[i][j - 1]) / (2 * dy);
            v[i][j] = (si[i - 1][j] - si[i + 1][j]) / (2 * dx);
        }
    }

    FILE *fp2;
    fp2 = fopen("400_si.plot", "w");
    fprintf(fp2, "VARIABLES = \"X\", \"Y\", \"PHI\"\n");
    fprintf(fp2, "ZONE T = \"BLOCK1\", I = 101, J = 101, F = POINT\n\n");
    for (int i = 1; i <= nx; i++) {
        for (int j = 1; j <= ny; j++) {
            fprintf(fp2, "%1f \t %1f \t %1f \n", i * dx, j * dy, si[i][j]);
        }
    }
    fclose(fp2);

    FILE *fp3;
    fp3 = fopen("400_w.plot", "w");
    fprintf(fp3, "VARIABLES = \"X\", \"Y\", \"W\"\n");
    fprintf(fp3, "ZONE T = \"BLOCK1\", I = 101, J = 101, F = POINT\n\n");
    for (int i = 1; i <= nx; i++) {
        for (int j = 1; j <= ny; j++) {
            fprintf(fp3, "%1f \t %1f \t %1f \n", i * dx, j * dy, w[i][j]);
        }
    }
    fclose(fp3);

    FILE *fp5;
    fp5 = fopen("Velocity_400.dat", "w");
    for (i = 1; i <= nx; i++) {
        for (j = 1; j <= ny; j++) {
            fprintf(fp5, "%f \t %f \t %f \t %f\n", i * dx, j * dy, u[i][j], v[i][j]);
        }
    }
    fclose(fp5);

    FILE *fp8;
    fp8 = fopen("all_400.dat", "w");
    for (i = 1; i <= nx; i++) {
        for (j = 1; j <= ny; j++) {
            fprintf(fp8, "%f \t %f \t %f \t %f \t %f \t %f\n", i * dx, j * dy, si[i][j], w[i][j], u[i][j], v[i][j]);
        }
    }
    fclose(fp8);

    FILE *fp6;
    fp6 = fopen("U_Centerline_400.dat", "w");
    for (j = 1; j <= ny; j++)
        fprintf(fp6, "%f \t%f \n", u[(nx - 1) / 2][j], j * dy);
    fclose(fp6);

    FILE *fp7;
    fp7 = fopen("V_centerline_400.dat", "w");
    for (i = 1; i <= nx; i++)
        fprintf(fp7, "%f \t%f \n", v[i][(ny - 1) / 2], i * dx);
    fclose(fp7);

    printf("%f\n", k);
    return 0;
}
